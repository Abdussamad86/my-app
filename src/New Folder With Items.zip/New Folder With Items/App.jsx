function SpeakerBadge({ name, role }) {
  return (
    <div>
      <h2>{name}</h2>
      <p>{role}</p>
    </div>
  );
}

function TopicTag({ topic, level }) {
  return (
    <div>
      <p>Topic: {topic}</p>
      <p>Level: {level}</p>
    </div>
  );
}

function SpeakerCard({
  name,
  role,
  company,
  topic,
  level,
  isFeatured
}) {
  return (
    <article>
      <p>
        {isFeatured ? "Featured Speaker" : "Community Speaker"}
      </p>

      <SpeakerBadge name={name} role={role} />

      <p>Company: {company}</p>

      <TopicTag topic={topic} level={level} />
    </article>
  );
}

export default function App() {
  return (
    <main>
      <h1>CodeBridge 2026 Speakers</h1>

      <SpeakerCard
        name="Ada Okafor"
        role="Frontend Engineer"
        company="Bright Labs"
        topic="Reusable React Components"
        level="Beginner"
        isFeatured={true}
      />

      <SpeakerCard
        name="Marcus Lee"
        role="Backend Developer"
        company="CloudWorks"
        topic="Building REST APIs"
        level="Intermediate"
        isFeatured={false}
      />

      <SpeakerCard
        name="Nia Williams"
        role="UI Engineer"
        company="Pixel Foundry"
        topic="Accessible Interfaces"
        level="Beginner"
        isFeatured={true}
      />

      <SpeakerCard
        name="Daniel Mensah"
        role="DevOps Engineer"
        company="LaunchStack"
        topic="Deploying Web Apps"
        level="Advanced"
        isFeatured={false}
      />
    </main>
  );
}