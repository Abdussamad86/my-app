function StudentCard({ name, course, level, city }) {
  return (
    <div>
      <h2>{name}</h2>
      <p>Course: {course}</p>
      <p>Level: {level}</p>
      <p>City: {city}</p>
    </div>
  )
}

function App() {
  return (
    <>
      <h1>Student Cards</h1>

      <StudentCard
        name="Abdussamad"
        course="Computer Science"
        level="100"
        city="Ibadan"
      />

      <StudentCard
        name="Chidi"
        course="Computer Engineering"
        level="200"
        city="Lagos"
      />

      <StudentCard
        name="Zainab"
        course="Information Technology"
        level="300"
        city="Osogbo"
      />
    </>
  )
}

export default App